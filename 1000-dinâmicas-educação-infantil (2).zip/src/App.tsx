/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, ReactNode, useRef, memo, useCallback } from 'react';
import { 
  CheckCircle2, 
  Users, 
  Clock, 
  Heart, 
  Star, 
  ChevronDown, 
  ShieldCheck, 
  Gift,
  Calendar,
  Zap,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Components ---

const Button = ({ children, className = "", onClick }: { children: ReactNode, className?: string, onClick?: () => void }) => (
  <button 
    onClick={onClick}
    className={`bg-[#1db954] hover:bg-[#1ed760] text-white font-bold py-4 px-8 rounded-full shadow-lg transition-all transform hover:scale-105 active:scale-95 uppercase tracking-wide ${className}`}
  >
    {children}
  </button>
);

const FeatureCard = memo(({ icon: Icon, title, description, isHighlighted = false }: { icon: any, title: string, description: string, isHighlighted?: boolean }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    className={`p-8 rounded-2xl bg-white border ${isHighlighted ? 'border-blue-500 shadow-blue-100 shadow-xl' : 'border-gray-100 shadow-sm'} flex flex-col items-center text-center`}
  >
    <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 ${isHighlighted ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-600'}`}>
      <Icon size={32} />
    </div>
    <h3 className="text-xl font-bold text-gray-900 mb-3">{title}</h3>
    <p className="text-gray-600 leading-relaxed">{description}</p>
  </motion.div>
));

const TestimonialCard = memo(({ stars, text, author, role, image }: { stars: number, text: string, author: string, role: string, image: string }) => (
  <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-col h-full">
    <div className="flex gap-1 mb-4">
      {[...Array(stars)].map((_, i) => (
        <Star key={i} size={16} className="fill-yellow-400 text-yellow-400" />
      ))}
    </div>
    <p className="text-gray-700 italic mb-6 flex-grow">"{text}"</p>
    <div className="flex items-center gap-3">
      <img src={image} alt={author} className="w-12 h-12 rounded-full object-cover" referrerPolicy="no-referrer" />
      <div>
        <p className="font-bold text-gray-900 text-sm">{author}</p>
        <p className="text-gray-500 text-xs">{role}</p>
      </div>
    </div>
  </div>
));

const Accordion = memo(({ title, content }: { title: string, content: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border border-blue-100 rounded-xl overflow-hidden mb-4 bg-blue-50/30">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-5 flex items-center justify-between text-left font-semibold text-gray-800 hover:bg-blue-50 transition-colors"
      >
        <span>{title}</span>
        <ChevronDown className={`transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} size={20} />
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="p-5 pt-0 text-gray-600 border-t border-blue-50">
              {content}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
});

const VturbPlayer = memo(({ id }: { id: string }) => {
  useEffect(() => {
    const scriptId = 'vturb-sdk-script';
    if (!document.getElementById(scriptId)) {
      const s = document.createElement("script");
      s.id = scriptId;
      s.src = "https://scripts.converteai.net/lib/js/smartplayer-wc/v4/sdk.js";
      s.async = true;
      document.head.appendChild(s);
    }
  }, []);

  const playerId = id.replace('vid-', '');

  return (
    <div className="max-w-[400px] mx-auto w-full">
      <div id={`ifr_${playerId}_wrapper`} style={{ margin: '0 auto', width: '100%', maxWidth: '400px' }}>
        <div style={{ position: 'relative', padding: '177.77777777777777% 0 0 0' }} id={`ifr_${playerId}_aspect`}>
          <iframe
            frameBorder="0"
            allowFullScreen
            src="about:blank"
            id={`ifr_${playerId}`}
            style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
            referrerPolicy="origin"
            onLoad={(e) => {
              const iframe = e.currentTarget;
              // Only update src if it's currently about:blank to avoid infinite loops
              try {
                if (iframe.contentWindow && iframe.contentWindow.location.href === 'about:blank') {
                  iframe.src = `https://scripts.converteai.net/992f5d21-a91c-4345-8984-985530ed57eb/players/${playerId}/v4/embed.html${window.location.search || '?'}&vl=${encodeURIComponent(window.location.href)}`;
                }
              } catch (err) {
                // If we can't access contentWindow (cross-origin), we might have already redirected
                // or we just set it once if it's the first load
                if (iframe.src.includes('about:blank')) {
                  iframe.src = `https://scripts.converteai.net/992f5d21-a91c-4345-8984-985530ed57eb/players/${playerId}/v4/embed.html${window.location.search || '?'}&vl=${encodeURIComponent(window.location.href)}`;
                }
              }
            }}
          />
        </div>
      </div>
    </div>
  );
});

const TestimonialCarousel = () => {
  const testimonials = [
    {
      stars: 5,
      text: "Agora minhas aulas são muito mais dinâmicas e as crianças amam! As atividades são super fáceis de aplicar e o engajamento dos pequenos aumentou muito.",
      author: "Profª Carla",
      role: "Professora de Educação Infantil",
      image: "https://picsum.photos/seed/carla/100/100"
    },
    {
      stars: 5,
      text: "Facilitou demais meu trabalho, economizo horas de preparação. O material é muito bem estruturado e as crianças se divertem enquanto aprendem.",
      author: "Profª Daniela",
      role: "Educadora há 8 anos",
      image: "https://picsum.photos/seed/daniela/100/100"
    },
    {
      stars: 5,
      text: "Uso até em casa com meu filho e ele aprendeu brincando! É incrível ver como ele se desenvolve com essas atividades tão criativas.",
      author: "Juliana",
      role: "Mãe dedicada",
      image: "https://picsum.photos/seed/juliana/100/100"
    },
    {
      stars: 5,
      text: "O melhor investimento que fiz este ano. As dinâmicas são variadas e cobrem diversos temas importantes para o desenvolvimento infantil.",
      author: "Profª Renata",
      role: "Coordenadora Pedagógica",
      image: "https://picsum.photos/seed/renata/100/100"
    },
    {
      stars: 5,
      text: "Material de altíssima qualidade. Os cartazes bônus são lindos e ajudaram muito na decoração e organização da minha sala.",
      author: "Profª Beatriz",
      role: "Professora da Rede Pública",
      image: "https://picsum.photos/seed/beatriz/100/100"
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 300 : -300,
      opacity: 0
    })
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset: number, velocity: number) => {
    return Math.abs(offset) * velocity;
  };

  const paginate = useCallback((newDirection: number) => {
    setDirection(newDirection);
    setCurrentIndex((prevIndex) => (prevIndex + newDirection + testimonials.length) % testimonials.length);
  }, [testimonials.length]);

  useEffect(() => {
    const timer = setInterval(() => {
      paginate(1);
    }, 5000);
    return () => clearInterval(timer);
  }, [paginate]);

  return (
    <div className="relative w-full max-w-4xl mx-auto px-4 md:px-12 py-8">
      <div className="relative h-[350px] md:h-[280px] overflow-hidden">
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 }
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={1}
            onDragEnd={(e, { offset, velocity }) => {
              const swipe = swipePower(offset.x, velocity.x);

              if (swipe < -swipeConfidenceThreshold) {
                paginate(1);
              } else if (swipe > swipeConfidenceThreshold) {
                paginate(-1);
              }
            }}
            className="absolute w-full h-full"
          >
            <TestimonialCard {...testimonials[currentIndex]} />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Buttons */}
      <button
        className="absolute left-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-white border border-gray-100 rounded-full shadow-md flex items-center justify-center text-gray-400 hover:text-blue-600 hover:border-blue-100 transition-all z-10"
        onClick={() => paginate(-1)}
      >
        <ChevronLeft size={24} />
      </button>
      <button
        className="absolute right-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-white border border-gray-100 rounded-full shadow-md flex items-center justify-center text-gray-400 hover:text-blue-600 hover:border-blue-100 transition-all z-10"
        onClick={() => paginate(1)}
      >
        <ChevronRight size={24} />
      </button>

      {/* Indicators */}
      <div className="flex justify-center gap-2 mt-6">
        {testimonials.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setDirection(index > currentIndex ? 1 : -1);
              setCurrentIndex(index);
            }}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentIndex ? "w-6 bg-blue-600" : "bg-gray-200"
            }`}
          />
        ))}
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [today, setToday] = useState('');

  useEffect(() => {
    const date = new Date();
    const formatted = date.toLocaleDateString('pt-BR');
    setToday(formatted);
  }, []);

  const scrollToPricing = () => {
    document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white font-sans text-gray-900 selection:bg-blue-100 selection:text-blue-900">
      
      {/* Top Banner */}
      <div className="bg-[#e31e24] text-white py-2 px-4 text-center text-sm font-medium">
        Desconto exclusivo somente HOJE ({today})
      </div>

      {/* Hero Section */}
      <header className="pt-16 pb-20 px-4 max-w-5xl mx-auto text-center">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-6xl font-black text-[#3b82f6] leading-tight mb-6"
        >
          Mais de 1000 Dinâmicas Para Educação Infantil prontas para imprimir ainda HOJE!
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto mb-10"
        >
          Dinâmicas lúdicas, educativas e prontas para aplicar com crianças da Educação Infantil — diversão e aprendizado em cada atividade!
        </motion.p>
        
        <div className="mb-12">
          <p className="text-gray-500 font-medium mb-4">Assista o Vídeo!</p>
          <VturbPlayer id="vid-699e252448d2f9414f0fb4dd" />
        </div>

        <Button onClick={scrollToPricing}>Quero Acessar Agora</Button>
      </header>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50/50 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-black text-center text-gray-900 mb-16">
            Por Que Escolher Nossas Dinâmicas?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <FeatureCard 
              icon={Users}
              title="Criadas especialmente para professores e pais"
              description="Material desenvolvido por educadores experientes, pensado especificamente para quem trabalha com crianças no dia a dia."
            />
            <FeatureCard 
              icon={CheckCircle2}
              title="Atividades testadas em sala de aula com resultados incríveis"
              description="Cada dinâmica foi aplicada e validada em ambientes reais de ensino, garantindo eficácia comprovada."
            />
            <FeatureCard 
              icon={Heart}
              isHighlighted={true}
              title="Promovem aprendizado natural e divertido"
              description="As crianças aprendem brincando, sem pressão, desenvolvendo habilidades de forma lúdica e prazerosa."
            />
            <FeatureCard 
              icon={Clock}
              title="Economize horas de planejamento: é só imprimir e aplicar"
              description="Material completamente pronto para uso. Sem necessidade de preparação adicional ou recursos extras."
            />
          </div>
        </div>
      </section>

      {/* Product Preview */}
      <section className="py-20 px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-black text-gray-900 mb-4">Conheça Nossas Dinâmicas</h2>
          <p className="text-gray-500 mb-12">Dinâmicas Especiais Para Educação Infantil</p>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative rounded-3xl overflow-hidden shadow-2xl border-8 border-white"
          >
            <img 
              src="https://broad-blue-fgkcvrn25n.edgeone.app/Gemini_Generated_Image_jo0fnzjo0fnzjo0f.png" 
              alt="Product Preview" 
              className="w-full h-auto"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-t from-blue-900/40 to-transparent pointer-events-none"></div>
          </motion.div>
        </div>
      </section>

      {/* Social Proof CTA */}
      <div className="py-10 text-center">
        <Button onClick={scrollToPricing}>QUERO ACESSAR AGORA</Button>
      </div>

      {/* Testimonials */}
      <section className="py-20 bg-white px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-black text-center text-gray-900 mb-4">O que nossos clientes dizem</h2>
          <div className="flex justify-center items-center gap-1 mb-2">
            {[...Array(5)].map((_, i) => <Star key={i} size={20} className="fill-yellow-400 text-yellow-400" />)}
          </div>
          <p className="text-center text-gray-600 font-medium mb-16">4.9/5 - 2.500+ avaliações</p>

          <TestimonialCarousel />

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 p-8 rounded-3xl bg-gray-50 border border-gray-100">
            <div className="text-center">
              <p className="text-3xl font-black text-blue-600">3.000+</p>
              <p className="text-gray-500 text-sm font-medium">Professores Ativos</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-black text-blue-600">98%</p>
              <p className="text-gray-500 text-sm font-medium">Recomendam</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-black text-blue-600">4.9/5</p>
              <p className="text-gray-500 text-sm font-medium">Avaliação Média</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-black text-blue-600">150+</p>
              <p className="text-gray-500 text-sm font-medium">Escolas Usando</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 bg-[#2563eb] px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-black text-center text-white mb-4 uppercase tracking-tight">ESCOLHA SEU PACOTE</h2>
          <p className="text-center text-blue-100 mb-16">Selecione a opção ideal para transformar suas aulas</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
            {/* Basic Plan */}
            <div className="bg-white rounded-[2rem] p-10 flex flex-col shadow-xl">
              <h3 className="text-2xl font-black text-gray-900 text-center mb-2">Pacote Básico</h3>
              <p className="text-center text-[#e31e24] line-through font-bold mb-4">R$67</p>
              <div className="text-center mb-2">
                <span className="text-5xl font-black text-[#1db954]">R$10</span>
              </div>
              <p className="text-center text-[#1db954] font-bold text-sm mb-10">Você economiza R$57,00</p>
              
              <ul className="space-y-4 mb-12 flex-grow">
                <li className="flex items-center gap-3 text-gray-700 font-medium">
                  <CheckCircle2 size={20} className="text-[#1db954]" />
                  1000 Dinâmicas Prontas em PDF
                </li>
                <li className="flex items-center gap-3 text-gray-700 font-medium">
                  <CheckCircle2 size={20} className="text-[#1db954]" />
                  Acesso Vitalício
                </li>
                <li className="flex items-center gap-3 text-gray-700 font-medium">
                  <CheckCircle2 size={20} className="text-[#1db954]" />
                  Garantia de 30 Dias
                </li>
              </ul>

              <a 
                href="https://pay.hotmart.com/M104624037V?checkoutMode=10"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-[#1db954] hover:bg-[#1ed760] text-white font-bold py-4 rounded-2xl transition-all transform hover:scale-[1.02] text-center"
              >
                Começar Agora
              </a>
            </div>

            {/* Premium Plan */}
            <div className="bg-white rounded-[2rem] p-10 flex flex-col shadow-2xl relative border-4 border-yellow-400">
              <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-yellow-400 text-gray-900 px-6 py-1 rounded-full text-xs font-black uppercase tracking-widest shadow-md">
                MAIS VENDIDO
              </div>
              
              <h3 className="text-2xl font-black text-gray-900 text-center mb-2">Pacote Premium</h3>
              <div className="flex items-center justify-center gap-3 mb-4">
                <p className="text-[#e31e24] line-through font-bold">R$ 97,00</p>
                <span className="bg-[#1db954] text-white text-[10px] font-black px-2 py-0.5 rounded">-72%</span>
              </div>
              <div className="text-center mb-2">
                <span className="text-5xl font-black text-[#1db954]">R$ 19,00</span>
              </div>
              <p className="text-center text-[#1db954] font-bold text-sm mb-10">Você economiza R$ 78,00</p>
              
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3 text-gray-700 font-medium">
                  <CheckCircle2 size={20} className="text-[#1db954]" />
                  1000 Dinâmicas Prontas em PDF
                </li>
                <li className="flex items-center gap-3 text-gray-700 font-medium">
                  <CheckCircle2 size={20} className="text-[#1db954]" />
                  Acesso Vitalício
                </li>
                <li className="flex items-center gap-3 text-gray-700 font-medium">
                  <CheckCircle2 size={20} className="text-[#1db954]" />
                  Garantia de 30 Dias
                </li>
              </ul>

              <div className="bg-yellow-50 p-4 rounded-xl mb-8">
                <p className="text-center text-yellow-800 font-black text-xs uppercase tracking-widest mb-4">BÔNUS INCLUSOS:</p>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3 text-yellow-900 text-sm font-bold">
                    <Gift size={16} className="text-yellow-600" />
                    20 Dinâmicas Extras Especiais
                  </li>
                  <li className="flex items-center gap-3 text-yellow-900 text-sm font-bold">
                    <Gift size={16} className="text-yellow-600" />
                    12 Cartazes Educativos
                  </li>
                  <li className="flex items-center gap-3 text-yellow-900 text-sm font-bold">
                    <Calendar size={16} className="text-yellow-600" />
                    Calendário de Datas Comemorativas
                  </li>
                  <li className="flex items-center gap-3 text-yellow-900 text-sm font-bold">
                    <Gift size={16} className="text-yellow-600" />
                    20 Atividades de Coordenação Motora
                  </li>
                </ul>
              </div>

              <a 
                href="https://pay.hotmart.com/Y104624681X?checkoutMode=10"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-[#1db954] hover:bg-[#1ed760] text-white font-black py-5 rounded-2xl transition-all transform hover:scale-[1.02] uppercase tracking-wide mb-4 text-center block"
              >
                QUERO O PACOTE PREMIUM
              </a>
              <p className="text-center text-gray-400 text-[10px] font-medium">+2.500 pessoas já escolheram este</p>
            </div>
          </div>
          
          <div className="mt-12 text-center text-blue-100 text-xs font-medium flex flex-wrap justify-center gap-x-6 gap-y-2">
            <span>Pagamento 100% seguro</span>
            <span>•</span>
            <span>Acesso imediato</span>
            <span>•</span>
            <span>Suporte dedicado</span>
          </div>
        </div>
      </section>

      {/* Guarantee */}
      <section className="py-24 px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <div className="w-24 h-24 bg-green-50 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
            <ShieldCheck size={48} />
          </div>
          <h2 className="text-3xl font-black text-[#1db954] mb-4">Garantia Incondicional de 30 Dias</h2>
          <p className="text-gray-600 leading-relaxed">
            Se não gostar, devolvemos seu dinheiro. Sem perguntas, sem complicações.
          </p>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-white px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-black text-center text-gray-900 mb-4">Perguntas Frequentes</h2>
          <p className="text-center text-gray-500 mb-12">Tire suas principais dúvidas sobre o material</p>
          
          <div className="space-y-4">
            <Accordion 
              title="O material é físico ou digital?"
              content="O material é 100% digital em formato PDF. Você receberá o acesso por e-mail imediatamente após a confirmação do pagamento e poderá baixar para imprimir quando quiser."
            />
            <Accordion 
              title="Preciso de preparo especial para aplicar as dinâmicas?"
              content="Não! Todas as dinâmicas foram pensadas para serem simples e práticas. O material inclui instruções passo a passo, lista de materiais (geralmente itens que você já tem) e os objetivos pedagógicos."
            />
            <Accordion 
              title="Posso usar tanto em sala quanto em casa?"
              content="Sim! As dinâmicas são versáteis e funcionam perfeitamente tanto para professores em sala de aula quanto para pais que desejam estimular o desenvolvimento dos filhos em casa."
            />
            <Accordion 
              title="Tenho suporte se precisar de ajuda?"
              content="Com certeza! Oferecemos suporte dedicado via e-mail e WhatsApp para tirar qualquer dúvida que você tenha sobre o material ou o acesso."
            />
          </div>

          <div className="mt-16 text-center">
            <Button onClick={scrollToPricing} className="bg-[#1db954] hover:bg-[#1ed760] text-xs px-10">
              TIREI MINHAS DÚVIDAS QUERO COMPRAR!
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 border-t border-gray-100 text-center text-gray-400 text-xs">
        <p>© {new Date().getFullYear()} 1000 Dinâmicas Educação Infantil. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}
